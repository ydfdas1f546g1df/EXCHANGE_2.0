//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MailSocket.rc
//
#define IDS_OK_MSG                      101
#define IDS_UNKNOWN_MSG                 102
#define IDS_WELCOME_MSG                 103
#define IDS_MSG_SYNTAX_ERROR            104
#define IDS_INCORRECT_PARAMETER         105
#define IDS_CMD_NOT_IMPLEMENTED         106
#define IDS_BAD_SEQUENCE                107
#define IDS_PARAM_NOT_IMPLEMENTED       108
#define IDS_SYSTEM_STATUS               109
#define IDS_HELP_MSG                    110
#define IDS_WELCOME                     111
#define IDS_STRING112                   112
#define IDS_STRING113                   113
#define IDS_STRING114                   114
#define IDS_STRING115                   115
#define IDS_STRING116                   116
#define IDS_STRING117                   117
#define IDS_STRING118                   118
#define IDS_STRING119                   119
#define IDS_STRING120                   120
#define IDS_STRING121                   121
#define IDS_STRING122                   122
#define IDS_STRING123                   123
#define IDS_STRING124                   124
#define IDS_APP_TITLE                   125

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
